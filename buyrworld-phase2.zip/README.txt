BUYRWORLD — SETUP GUIDE (Phase 2: real AI + payments)
======================================================

WHAT'S IN THIS FOLDER
- index.html      → your whole website (all pages + content)
- api/chat.js     → the Buyr AI brain (keeps your AI key secret)
- README.txt      → this guide

The site works the moment it's deployed. If the AI key isn't set up yet,
the chat automatically uses demo answers, so nothing ever looks broken.

------------------------------------------------------
STEP A — GET YOUR AI KEY (~5 min, do once)
------------------------------------------------------
1. Go to console.anthropic.com and sign up
2. Click Billing → add a card and £5–10 of credit
   (typical chat answers cost well under 1p each)
3. Click API Keys → Create Key → copy it somewhere safe
   It looks like: sk-ant-xxxxxxxx

------------------------------------------------------
STEP B — PUT THE CODE ON GITHUB (~5 min)
------------------------------------------------------
1. Go to github.com → sign up (free)
2. Click the + (top right) → New repository
   Name: buyrworld → keep it Private → Create repository
3. Click "uploading an existing file" link on the next screen
4. Unzip this folder on your computer, then drag in:
   - index.html
   - the whole "api" folder (drag the folder itself)
5. Click "Commit changes" (green button)

------------------------------------------------------
STEP C — DEPLOY ON VERCEL (~5 min)
------------------------------------------------------
1. Go to vercel.com → Sign up → choose "Continue with GitHub"
2. Click Add New… → Project → Import next to "buyrworld"
3. BEFORE clicking Deploy, open "Environment Variables" and add:
      Name:  ANTHROPIC_API_KEY
      Value: (paste your sk-ant-... key)
4. Click Deploy. After ~1 minute you get a live link like
   buyrworld.vercel.app — open it and test the AI chat!

------------------------------------------------------
STEP D — YOUR DOMAIN (GoDaddy)
------------------------------------------------------
1. In Vercel: your project → Settings → Domains → add buyrworld.com
2. Vercel shows you a DNS record (usually an "A" record 76.76.21.21
   and a CNAME for www)
3. In GoDaddy: My Products → DNS next to your domain → edit the
   A record and CNAME to match what Vercel shows → Save
4. Wait up to a few hours. Done — with free HTTPS.
   (If you connected the domain to Netlify earlier, remove it there first.)

------------------------------------------------------
STEP E — TAKE PAYMENTS WITH STRIPE (~20 min)
------------------------------------------------------
1. Go to stripe.com → sign up → complete the business details
2. In Stripe: Product catalogue → Add product
   (e.g. "RFQ Template", £12, one-off) — repeat for each template,
   and add "Pro Membership" £9.99 as a recurring/monthly price
3. For each product: click it → Create payment link → copy the link
4. Open index.html, find the section near the bottom that says
   PAYMENT_LINKS, and paste each link between the quotes, e.g.:
      "RFQ Template":"https://buy.stripe.com/abc123",
5. Re-upload index.html to GitHub (repo → click index.html →
   pencil icon won't take big pastes; easier: Add file → Upload files
   → drag the new index.html → Commit). Vercel redeploys automatically.

To deliver the actual template files after purchase, the simplest
no-code option: in each Stripe payment link's settings, add a
confirmation message containing a Google Drive/Dropbox download link.
(Later we can automate delivery properly.)

------------------------------------------------------
STEP F — COMMUNITY WAITLIST FORM (optional, ~5 min)
------------------------------------------------------
1. Go to formspree.io → sign up free → New form → copy your form ID
2. In index.html, find YOUR_FORM_ID and replace it with your ID
3. Waitlist emails now arrive in your inbox

------------------------------------------------------
WHAT'S DELIBERATELY NOT HERE YET
------------------------------------------------------
User accounts/logins and a members-only dashboard need a database —
that's a bigger build (Phase 3). Until then, Stripe payment links +
email delivery cover sales, and the AI works for everyone.

Updating the site: ask Claude for changes → get a new index.html →
upload it to GitHub → Vercel redeploys automatically.
